const fs = require('fs');
const content = fs.readFileSync('index.html', 'utf-8');
const lines = content.split('\n');

let depth = 0;
let labStart = -1, labEnd = -1;
lines.forEach((line, i) => {
  if (line.includes('id="security-lab"')) labStart = i;
  if (labStart !== -1 && labEnd === -1 && line.includes('id="projects"')) labEnd = i;
});

console.log('--- #security-lab Section Tag Balance ---');
for (let i = labStart; i <= labEnd; i++) {
  const line = lines[i];
  const opens = (line.match(/<div\b/g) || []).length;
  const closes = (line.match(/<\/div>/g) || []).length;
  depth += opens - closes;
  if (line.includes('lab-panel') || line.includes('container') || line.includes('</section>')) {
    console.log(`Line ${i+1} (depth ${depth}): ${line.trim().slice(0, 70)}`);
  }
}
console.log('Final #security-lab container depth before </section>:', depth);

console.log('\n--- Full Document Section Tag Count ---');
const sections = content.match(/<section[\s\S]*?<\/section>/gi) || [];
sections.forEach((sec, idx) => {
  const idMatch = sec.match(/id="([^"]+)"/);
  const id = idMatch ? idMatch[1] : `section-${idx+1}`;
  const dOpens = (sec.match(/<div\b/g) || []).length;
  const dCloses = (sec.match(/<\/div>/g) || []).length;
  console.log(`[${id}] <div> opened: ${dOpens}, closed: ${dCloses}, balanced: ${dOpens === dCloses}`);
});
