/**
 * DINESH MOHAN — DEFENSIVE SECURITY & SYSTEMS PORTFOLIO
 * High-performance, accessible, vanilla JavaScript client script
 * Features: View Transitions Theme, Sliding Nav Pill, Live IST Clock,
 * Intro Cyber Loader, Command Palette, Interactive Security Lab Feed,
 * Architecture Diagram Inspector, and Accessible Lightbox Modal.
 */

/** Public-facing content policy. Keep false in production so editorial placeholders stay hidden. */
const SHOW_PLACEHOLDERS = false;
if (document.documentElement) {
  document.documentElement.dataset.showPlaceholders = String(SHOW_PLACEHOLDERS);
}

document.addEventListener('DOMContentLoaded', () => {
  initIntroLoader();
  initLiveClock();
  initThemeTransitions();
  initNavScrollAndPill();
  initSmoothScroll();
  initScrollReveal();
  initMobileNav();
  initImageFallback();
  initGallerySwitcher();
  initLabTabs();
  initAlertFeed();
  initCommandPalette();
  initLightboxModal();
  initArchitectureDiagram();
});

/**
 * 0. High-Tech Cyber Terminal Intro Loader
 */
function initIntroLoader() {
  const loader = document.getElementById('intro-loader');
  const progressBar = document.getElementById('loader-progress-bar');
  if (!loader) return;

  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let alreadySeen = false;
  try {
    alreadySeen = sessionStorage.getItem('dm_intro_seen') === 'true';
  } catch (e) {
    // Storage can be unavailable in locked-down browsers; the loader still works without it.
  }

  // Skip loader if user previously saw it in this session or prefers reduced motion
  if (alreadySeen || prefersReduced) {
    loader.style.display = 'none';
    document.body.classList.remove('loading-lock');
    return;
  }

  document.body.classList.add('loading-lock');

  let progress = 0;
  const interval = setInterval(() => {
    progress += Math.floor(Math.random() * 30) + 25;
    if (progress >= 100) {
      progress = 100;
      clearInterval(interval);
      if (progressBar) progressBar.style.width = '100%';
      
      setTimeout(() => {
        loader.classList.add('fade-out');
        document.body.classList.remove('loading-lock');
        try { sessionStorage.setItem('dm_intro_seen', 'true'); } catch (e) { /* Ignore unavailable storage. */ }
        setTimeout(() => {
          loader.style.display = 'none';
        }, 450);
      }, 150);
    } else {
      if (progressBar) progressBar.style.width = `${progress}%`;
    }
  }, 35);

  // Allow instant skip on click or keypress
  function handleLoaderKey(event) {
    if (!['Escape', 'Enter', ' '].includes(event.key)) return;
    event.preventDefault();
    dismissLoader();
  }

  function dismissLoader() {
    clearInterval(interval);
    document.removeEventListener('keydown', handleLoaderKey);
    loader.classList.add('fade-out');
    document.body.classList.remove('loading-lock');
    try { sessionStorage.setItem('dm_intro_seen', 'true'); } catch (e) { /* Ignore unavailable storage. */ }
    setTimeout(() => { loader.style.display = 'none'; }, 450);
  }

  loader.addEventListener('click', dismissLoader);
  document.addEventListener('keydown', handleLoaderKey);
}

/**
 * 1. Live Chennai, India (IST) Clock
 */
function initLiveClock() {
  const clockEl = document.getElementById('live-ist-clock');
  if (!clockEl) return;

  function updateClock() {
    try {
      const now = new Date();
      const options = {
        timeZone: 'Asia/Kolkata',
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      };
      const formatter = new Intl.DateTimeFormat([], options);
      clockEl.textContent = `${formatter.format(now)} IST`;
    } catch (e) {
      // Fallback calculation for UTC+5:30
      const now = new Date();
      const utc = now.getTime() + (now.getTimezoneOffset() * 60000);
      const istTime = new Date(utc + (3600000 * 5.5));
      const pad = (n) => String(n).padStart(2, '0');
      clockEl.textContent = `${pad(istTime.getHours())}:${pad(istTime.getMinutes())}:${pad(istTime.getSeconds())} IST`;
    }
  }

  updateClock();
  setInterval(updateClock, 1000);
}

/**
 * 2. Theme Switching (Light / Dark) with View Transitions API or direct fallback
 */
function initThemeTransitions() {
  const themeBtns = document.querySelectorAll('.theme-toggle-btn, #theme-toggle');
  const root = document.documentElement;

  const getTheme = () => root.getAttribute('data-theme') || 'dark';

  function applyTheme(targetTheme) {
    root.classList.add('theme-transitioning');
    root.setAttribute('data-theme', targetTheme);
    try {
      localStorage.setItem('dm_theme', targetTheme);
    } catch (e) {
      console.warn('LocalStorage not available:', e);
    }
    updateThemeIcons(targetTheme);
    setTimeout(() => {
      root.classList.remove('theme-transitioning');
    }, 450);
  }

  function updateThemeIcons(theme) {
    const isDark = theme === 'dark';
    themeBtns.forEach((btn) => {
      btn.setAttribute('aria-label', `Switch to ${isDark ? 'light' : 'dark'} theme`);
      btn.setAttribute('title', `Switch to ${isDark ? 'light' : 'dark'} theme`);
      btn.innerHTML = isDark
        ? `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
             <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
           </svg>`
        : `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
             <circle cx="12" cy="12" r="5"></circle>
             <line x1="12" y1="1" x2="12" y2="3"></line>
             <line x1="12" y1="21" x2="12" y2="23"></line>
             <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
             <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
             <line x1="1" y1="12" x2="3" y2="12"></line>
             <line x1="21" y1="12" x2="23" y2="12"></line>
             <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
             <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
           </svg>`;
    });
  }

  // Initial icon setup
  updateThemeIcons(getTheme());

  themeBtns.forEach((btn) => {
    btn.addEventListener('click', (e) => {
      const currentTheme = getTheme();
      const targetTheme = currentTheme === 'dark' ? 'light' : 'dark';
      const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

      if (document.startViewTransition && !prefersReduced) {
        const rect = btn.getBoundingClientRect();
        const x = rect.left + rect.width / 2;
        const y = rect.top + rect.height / 2;
        const endRadius = Math.hypot(
          Math.max(x, window.innerWidth - x),
          Math.max(y, window.innerHeight - y)
        );

        const transition = document.startViewTransition(() => {
          applyTheme(targetTheme);
        });

        transition.ready.then(() => {
          document.documentElement.animate(
            {
              clipPath: [
                `circle(0px at ${x}px ${y}px)`,
                `circle(${endRadius}px at ${x}px ${y}px)`
              ]
            },
            {
              duration: 500,
              easing: 'cubic-bezier(0.22, 1, 0.36, 1)',
              pseudoElement: '::view-transition-new(root)'
            }
          );
        });
      } else {
        applyTheme(targetTheme);
      }
    });
  });

  // Expose toggle globally for command palette
  window.toggleTheme = () => {
    const currentTheme = getTheme();
    applyTheme(currentTheme === 'dark' ? 'light' : 'dark');
  };
}

/**
 * 3. Sticky Header, Scroll Progress Bar & Sliding Nav Pill
 */
function initNavScrollAndPill() {
  const header = document.getElementById('header');
  const progressBar = document.getElementById('scroll-progress');
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');
  const pillIndicator = document.getElementById('nav-pill-indicator');

  function handleScroll() {
    const scrollY = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const progress = docHeight > 0 ? (scrollY / docHeight) * 100 : 0;

    if (progressBar) {
      progressBar.style.width = `${progress}%`;
    }

    if (header) {
      if (scrollY > 30) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }

    // Scroll spy for active section
    const scrollTrigger = scrollY + 160;
    const isAtBottom = (window.innerHeight + scrollY) >= (document.documentElement.scrollHeight - 60);

    let currentSectionId = null;
    if (isAtBottom) {
      currentSectionId = 'contact';
    } else {
      sections.forEach((section) => {
        const top = section.offsetTop;
        const height = section.offsetHeight;
        const id = section.getAttribute('id');
        if (scrollTrigger >= top && scrollTrigger < top + height) {
          currentSectionId = id;
        }
      });
    }

    if (currentSectionId) {
      navLinks.forEach((link) => {
        const href = link.getAttribute('href');
        const matches = href === `#${currentSectionId}`;
        if (matches) {
          if (!link.classList.contains('active')) {
            navLinks.forEach((l) => {
              l.classList.remove('active');
              l.removeAttribute('aria-current');
            });
            link.classList.add('active');
            link.setAttribute('aria-current', 'page');
            movePill(link);
          }
        }
      });
    }
  }

  function movePill(targetLink) {
    if (!pillIndicator || !targetLink) return;
    const linkRect = targetLink.getBoundingClientRect();
    const parent = pillIndicator.parentElement;
    if (!parent) return;
    const parentRect = parent.getBoundingClientRect();
    const leftOffset = linkRect.left - parentRect.left;
    pillIndicator.style.transform = `translateX(${leftOffset}px)`;
    pillIndicator.style.width = `${linkRect.width}px`;
    pillIndicator.style.opacity = '1';
  }

  // Hover tracking for pill indicator
  navLinks.forEach((link) => {
    link.addEventListener('mouseenter', () => {
      movePill(link);
    });
  });

  const navList = document.getElementById('nav-list');
  if (navList) {
    navList.addEventListener('mouseleave', () => {
      const active = document.querySelector('.nav-link.active') || navLinks[0];
      if (active) movePill(active);
    });
  }

  // Position pill initially
  setTimeout(() => {
    const active = document.querySelector('.nav-link.active') || navLinks[0];
    if (active) movePill(active);
  }, 120);

  window.addEventListener('scroll', handleScroll, { passive: true });
  window.addEventListener('resize', () => {
    const active = document.querySelector('.nav-link.active') || navLinks[0];
    if (active) movePill(active);
  });
  handleScroll();
}

/**
 * 4. Smooth Anchor Scrolling
 */
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', (e) => {
      const targetId = anchor.getAttribute('href');
      if (!targetId || targetId === '#' || targetId === '#main-content') return;
      const targetEl = document.querySelector(targetId);
      if (targetEl) {
        e.preventDefault();
        const headerOffset = 76;
        const elementPosition = targetEl.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

        const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        window.scrollTo({
          top: offsetPosition,
          behavior: reduceMotion ? 'auto' : 'smooth'
        });

        // Close mobile drawer if open
        const drawer = document.getElementById('mobile-nav-drawer');
        const menuBtn = document.getElementById('mobile-menu-btn');
        if (drawer && drawer.classList.contains('open')) {
          drawer.classList.remove('open');
          if (menuBtn) menuBtn.setAttribute('aria-expanded', 'false');
        }
      }
    });
  });
}

/**
 * 4.5 Smooth Scroll Reveal via IntersectionObserver
 */
function initScrollReveal() {
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (prefersReduced) return;

  const selector = [
    '.section-head',
    '.impact-card',
    '.about-narrative-card',
    '.bento-card',
    '.service-card',
    '.project-card',
    '.case-study-card',
    '.toolkit-category',
    '.timeline-card',
    '.cert-card',
    '.contact-cta-card',
    '.security-feed-terminal',
    '.arch-diagram-card'
  ].join(', ');

  const targets = document.querySelectorAll(selector);
  if (!targets.length) return;

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const el = entry.target;
        obs.unobserve(el);

        const parent = el.parentElement;
        if (parent) {
          const siblings = Array.from(parent.querySelectorAll('.reveal-on-scroll:not(.revealed)'));
          const idx = siblings.indexOf(el);
          if (idx >= 0 && idx < 6) {
            el.style.transitionDelay = `${idx * 80}ms`;
          }
        }

        el.classList.add('revealed');
      }
    });
  }, {
    threshold: 0.05,
    rootMargin: '200px 0px 200px 0px'
  });

  targets.forEach((el) => {
    if (el.closest('.hero-section')) return;
    el.classList.add('reveal-on-scroll');
    observer.observe(el);
  });

  // Safety fallback: reveal any remaining hidden elements after 1.2s
  // so full-page captures, headless browsers, or print renderers never leave content invisible
  const revealAllRemaining = () => {
    document.querySelectorAll('.reveal-on-scroll:not(.revealed)').forEach((el) => {
      el.classList.add('revealed');
    });
  };

  if (document.readyState === 'complete') {
    setTimeout(revealAllRemaining, 1200);
  } else {
    window.addEventListener('load', () => setTimeout(revealAllRemaining, 1200));
  }
}

/**
 * 5. Mobile Navigation Drawer
 */
function initMobileNav() {
  const menuBtn = document.getElementById('mobile-menu-btn');
  const drawer = document.getElementById('mobile-nav-drawer');

  if (menuBtn && drawer) {
    menuBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = drawer.classList.toggle('open');
      menuBtn.setAttribute('aria-expanded', String(isOpen));
    });

    // Close when clicking outside
    document.addEventListener('click', (e) => {
      if (drawer.classList.contains('open') && !drawer.contains(e.target) && !menuBtn.contains(e.target)) {
        drawer.classList.remove('open');
        menuBtn.setAttribute('aria-expanded', 'false');
      }
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && drawer.classList.contains('open')) {
        drawer.classList.remove('open');
        menuBtn.setAttribute('aria-expanded', 'false');
      }
    });
  }
}

/**
 * 6. Portrait Fallback Handling
 */
function initImageFallback() {
  const portraitImg = document.querySelector('.hero-portrait-img, .hero-morph-img');
  if (portraitImg) {
    portraitImg.addEventListener('error', () => {
      portraitImg.style.display = 'none';
      const fallback = document.createElement('div');
      fallback.style.width = '100%';
      fallback.style.height = '100%';
      fallback.style.display = 'flex';
      fallback.style.alignItems = 'center';
      fallback.style.justifyContent = 'center';
      fallback.style.fontFamily = 'var(--font-mono)';
      fallback.style.fontSize = '32px';
      fallback.style.fontWeight = '700';
      fallback.style.color = 'var(--accent)';
      fallback.textContent = 'DM';
      portraitImg.parentElement.appendChild(fallback);
    });
  }
}

/**
 * 7. Browser Mockup Gallery Switchers
 */
function initGallerySwitcher() {
  document.querySelectorAll('.project-browser-mockup').forEach((mockup) => {
    const mainImg = mockup.querySelector('.gallery-main-img');
    const zoomTrigger = mockup.querySelector('.gallery-zoom-trigger');
    const thumbs = mockup.querySelectorAll('.gallery-thumb-btn');

    thumbs.forEach((thumb) => {
      thumb.addEventListener('click', () => {
        if (thumb.classList.contains('active')) return;
        thumbs.forEach((t) => t.classList.remove('active'));
        thumb.classList.add('active');
        const newSrc = thumb.getAttribute('data-img-src');
        const newTitle = thumb.getAttribute('data-title') || 'Artifact Screenshot';
        if (mainImg && newSrc) {
          mainImg.style.transition = 'opacity 180ms ease, transform 180ms ease';
          mainImg.style.opacity = '0.35';
          mainImg.style.transform = 'scale(0.99)';

          setTimeout(() => {
            mainImg.setAttribute('src', newSrc);
            mainImg.setAttribute('alt', newTitle);
            mainImg.onload = () => {
              mainImg.style.opacity = '1';
              mainImg.style.transform = 'scale(1)';
            };
            setTimeout(() => {
              mainImg.style.opacity = '1';
              mainImg.style.transform = 'scale(1)';
            }, 120);
          }, 150);
        }
        if (zoomTrigger && newSrc) {
          zoomTrigger.setAttribute('data-zoom-src', newSrc);
          zoomTrigger.setAttribute('data-zoom-title', newTitle);
        }
      });
    });
  });
}

/**
 * 8. Security Lab Tab Switcher
 */
function initLabTabs() {
  const tabBtns = Array.from(document.querySelectorAll('.lab-tab-btn'));
  const panels = Array.from(document.querySelectorAll('.lab-tab-panel'));
  if (!tabBtns.length || !panels.length) return;

  function activateTab(btn, moveFocus = false) {
    const targetTab = btn.getAttribute('data-tab');
    tabBtns.forEach((tab) => {
      const active = tab === btn;
      tab.classList.toggle('active', active);
      tab.setAttribute('aria-selected', String(active));
      tab.tabIndex = active ? 0 : -1;
    });
    panels.forEach((panel) => {
      const active = panel.id === `lab-panel-${targetTab}`;
      panel.classList.toggle('active', active);
      panel.hidden = !active;
    });
    if (moveFocus) btn.focus();
  }

  tabBtns.forEach((btn, index) => {
    btn.addEventListener('click', () => activateTab(btn));
    btn.addEventListener('keydown', (event) => {
      let nextIndex = index;
      if (event.key === 'ArrowRight' || event.key === 'ArrowDown') nextIndex = (index + 1) % tabBtns.length;
      else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') nextIndex = (index - 1 + tabBtns.length) % tabBtns.length;
      else if (event.key === 'Home') nextIndex = 0;
      else if (event.key === 'End') nextIndex = tabBtns.length - 1;
      else return;
      event.preventDefault();
      activateTab(tabBtns[nextIndex], true);
    });
  });

  const initial = tabBtns.find((btn) => btn.classList.contains('active')) || tabBtns[0];
  activateTab(initial);
}
/**
 * 9. Live Simulated Wazuh Threat Detection Feed
 */
function initAlertFeed() {
  const feedContainer = document.getElementById('security-feed-stream');
  const pauseBtn = document.getElementById('feed-pause-btn');
  const bruteBtn = document.getElementById('feed-trigger-brute');
  const fimBtn = document.getElementById('feed-trigger-fim');
  const clearBtn = document.getElementById('feed-clear-btn');
  if (!feedContainer) return;

  const simulatedPool = [
    {
      level: 10,
      badge: 'ALERT',
      type: 'rule',
      code: 'Rule 5710',
      text: 'sshd: Multiple failed password attempts from 203.0.113.42 (Brute-Force Anomaly)',
      meta: 'EC2-Security-Gateway • Port 22 • Drop Triggered'
    },
    {
      level: 7,
      badge: 'FIM',
      type: 'fim',
      code: 'Rule 550',
      text: 'Integrity Checksum Drift: /etc/pam.d/common-auth modified by UID 0',
      meta: 'Hospital-HIMS-Node01 • SHA-256 Changed • Incident Logged'
    },
    {
      level: 5,
      badge: 'AUDIT',
      type: 'audit',
      code: 'Rule 5402',
      text: 'Successful sudo privilege escalation: user `dinesh` -> root via /usr/bin/apt-get',
      meta: 'Bastion-Host • Session ID: #8821'
    },
    {
      level: 4,
      badge: 'HEALTH',
      type: 'zabbix',
      code: 'ZBX-AGENT',
      text: 'MySQL Replication Slave IO Thread Active • Seconds Behind Master: 0s',
      meta: 'DB-Cluster-02 • Memory: 41% • IOPS: Normal'
    },
    {
      level: 8,
      badge: 'PATCH',
      type: 'patch',
      code: 'Action1-CVE',
      text: 'Automated patch remediation: CVE-2024-6387 (RegreSSHion) scheduled window executed',
      meta: '14 Endpoints Reached • Status: Patching Complete • No Workday Disruption'
    },
    {
      level: 9,
      badge: 'FIREWALL',
      type: 'rule',
      code: 'Rule 4101',
      text: 'UFW dropped inbound SYN packet on port 3306 from unauthorized external subnet',
      meta: 'Core-VPC-Firewall • MySQL Isolated'
    }
  ];

  let isPaused = false;
  let poolIndex = 0;

  function appendAlert(alertData, isManual = false) {
    const alertEl = document.createElement('div');
    alertEl.className = `alert-item level-${alertData.level} ${isManual ? 'manual-trigger' : ''}`;
    
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });

    alertEl.innerHTML = `
      <div class="alert-top">
        <span class="alert-badge badge-${alertData.type}">${alertData.badge}</span>
        <span class="alert-code">${alertData.code}</span>
        <span class="alert-lvl">Lvl ${alertData.level}</span>
        <span class="alert-time">${timeStr}</span>
      </div>
      <div class="alert-message">${alertData.text}</div>
      <div class="alert-meta">${alertData.meta}</div>
    `;

    feedContainer.prepend(alertEl);

    // Keep max 15 alerts to avoid memory growth
    const items = feedContainer.querySelectorAll('.alert-item');
    if (items.length > 15) {
      items[items.length - 1].remove();
    }
  }

  // Interval timer for live streaming
  const alertInterval = setInterval(() => {
    if (!isPaused) {
      const item = simulatedPool[poolIndex % simulatedPool.length];
      poolIndex++;
      appendAlert(item);
    }
  }, 4500);

  if (pauseBtn) {
    pauseBtn.addEventListener('click', () => {
      isPaused = !isPaused;
      pauseBtn.innerHTML = isPaused
        ? `<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg><span>Resume Feed</span>`
        : `<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg><span>Pause Feed</span>`;
    });
  }

  if (bruteBtn) {
    bruteBtn.addEventListener('click', () => {
      appendAlert({
        level: 10,
        badge: 'HUNT-ALERT',
        type: 'rule',
        code: 'Rule 5712',
        text: 'SIMULATED ATTACK: SSH brute force surge (30 attempts/sec) blocked by Wazuh Active Response',
        meta: 'Active IP Shun Triggered: 198.51.100.77 quarantined for 3600s'
      }, true);
    });
  }

  if (fimBtn) {
    fimBtn.addEventListener('click', () => {
      appendAlert({
        level: 7,
        badge: 'FIM-TEST',
        type: 'fim',
        code: 'Rule 554',
        text: 'MANUAL TRIGGER: File attribute drift detected on /etc/shadow [Permissions altered: 0640 -> 0644]',
        meta: 'Audit Rule Triggered: Reverted to CIS Benchmark baseline'
      }, true);
    });
  }

  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      feedContainer.innerHTML = '';
      appendAlert({
        level: 1,
        badge: 'SYSTEM',
        type: 'audit',
        code: 'SEC-LOG',
        text: 'Console log buffer cleared by administrator.',
        meta: 'Demo stream ready — no live SIEM connection is made.'
      });
    });
  }
}

/**
 * 10. Interactive Command Palette (Cmd+K / Ctrl+K)
 */
function initCommandPalette() {
  const palette = document.getElementById('command-palette');
  const paletteTrigger = document.getElementById('cmd-palette-btn');
  const input = document.getElementById('palette-input');
  const resultsContainer = document.getElementById('palette-results');
  const overlay = document.getElementById('palette-overlay');
  if (!palette || !input || !resultsContainer) return;

  const commands = [
    { id: 'jump-about', title: 'Jump to About & Background', cat: 'Navigation', action: () => scrollToSection('#about') },
    { id: 'jump-lab', title: 'Jump to Defensive Security Lab (Wazuh & Ollama)', cat: 'Navigation', action: () => scrollToSection('#security-lab') },
    { id: 'jump-projects', title: 'Jump to Featured Projects', cat: 'Navigation', action: () => scrollToSection('#projects') },
    { id: 'jump-skills', title: 'Jump to Technical Toolkit', cat: 'Navigation', action: () => scrollToSection('#skills') },
    { id: 'jump-experience', title: 'Jump to Experience History', cat: 'Navigation', action: () => scrollToSection('#experience') },
    { id: 'jump-certs', title: 'Jump to Verified Certifications', cat: 'Navigation', action: () => scrollToSection('#certifications-anchor') },
    { id: 'jump-contact', title: 'Jump to Contact Section', cat: 'Navigation', action: () => scrollToSection('#contact') },
    { id: 'cmd-theme', title: 'Toggle Theme (Dark / Light Mode)', cat: 'Appearance', action: () => window.toggleTheme && window.toggleTheme() },
    { id: 'cmd-resume', title: 'Download Official Resume PDF', cat: 'Action', action: () => triggerResumeDownload() },
    { id: 'cmd-linkedin', title: 'Open LinkedIn Profile', cat: 'External', action: () => window.open('https://www.linkedin.com/in/dinesh-mohan-894574227', '_blank', 'noopener,noreferrer') },
    { id: 'cmd-github', title: 'Open GitHub Profile', cat: 'External', action: () => window.open('https://github.com/dinesh-190704', '_blank', 'noopener,noreferrer') }
  ];

  let selectedIndex = 0;
  let filteredCommands = [...commands];
  let paletteReturnFocus = null;

  function openPalette() {
    paletteReturnFocus = document.activeElement;
    selectedIndex = 0;
    palette.classList.add('open');
    palette.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    input.value = '';
    renderCommands(commands);
    setTimeout(() => input.focus(), 50);
  }

  function closePalette() {
    palette.classList.remove('open');
    palette.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    if (paletteReturnFocus && typeof paletteReturnFocus.focus === 'function') paletteReturnFocus.focus();
  }

  function scrollToSection(targetId) {
    closePalette();
    const targetEl = document.querySelector(targetId);
    if (targetEl) {
      const headerOffset = 76;
      const elementPosition = targetEl.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      window.scrollTo({ top: offsetPosition, behavior: reduceMotion ? 'auto' : 'smooth' });
    }
  }

  function triggerResumeDownload() {
    closePalette();
    const link = document.createElement('a');
    link.href = 'assets/Dinesh_Mohan_Resume.pdf';
    link.download = 'Dinesh_Mohan_Resume.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  function renderCommands(list) {
    filteredCommands = list;
    resultsContainer.innerHTML = '';

    if (list.length === 0) {
      input.removeAttribute('aria-activedescendant');
      resultsContainer.innerHTML = `<div class="palette-empty">No matching commands found</div>`;
      return;
    }

    list.forEach((cmd, idx) => {
      const item = document.createElement('div');
      item.className = `palette-item ${idx === selectedIndex ? 'selected' : ''}`;
      item.id = `palette-option-${idx}`;
      item.setAttribute('role', 'option');
      item.setAttribute('aria-selected', String(idx === selectedIndex));
      item.innerHTML = `
        <div class="palette-item-content">
          <span class="palette-item-title">${cmd.title}</span>
          <span class="palette-item-cat">${cmd.cat}</span>
        </div>
        <kbd class="palette-item-enter">&crarr;</kbd>
      `;

      item.addEventListener('click', () => {
        cmd.action();
        closePalette();
      });

      item.addEventListener('mouseenter', () => {
        selectedIndex = idx;
        updateSelection();
      });

      resultsContainer.appendChild(item);
    });
    const activeItem = resultsContainer.querySelector('.palette-item.selected');
    if (activeItem) input.setAttribute('aria-activedescendant', activeItem.id);
  }

  function updateSelection() {
    const items = resultsContainer.querySelectorAll('.palette-item');
    items.forEach((item, idx) => {
      const selected = idx === selectedIndex;
      item.classList.toggle('selected', selected);
      item.setAttribute('aria-selected', String(selected));
      if (selected) {
        input.setAttribute('aria-activedescendant', item.id);
        item.scrollIntoView({ block: 'nearest' });
      }
    });
  }

  input.addEventListener('input', () => {
    const query = input.value.trim().toLowerCase();
    selectedIndex = 0;
    if (!query) {
      renderCommands(commands);
    } else {
      const filtered = commands.filter(c => 
        c.title.toLowerCase().includes(query) || c.cat.toLowerCase().includes(query)
      );
      renderCommands(filtered);
    }
  });

  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (filteredCommands.length) {
        selectedIndex = (selectedIndex + 1) % filteredCommands.length;
        updateSelection();
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (filteredCommands.length) {
        selectedIndex = (selectedIndex - 1 + filteredCommands.length) % filteredCommands.length;
        updateSelection();
      }
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filteredCommands[selectedIndex]) {
        filteredCommands[selectedIndex].action();
        closePalette();
      }
    } else if (e.key === 'Escape') {
      closePalette();
    }
  });

  // Global keyboard shortcut: Ctrl+K or Cmd+K
  document.addEventListener('keydown', (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      if (palette.classList.contains('open')) {
        closePalette();
      } else {
        openPalette();
      }
    }
  });

  if (paletteTrigger) {
    paletteTrigger.addEventListener('click', openPalette);
  }

  if (overlay) {
    overlay.addEventListener('click', closePalette);
  }
}

/**
 * 11. Interactive Defensive Architecture Diagram Tooltip / Highlight
 */
function initArchitectureDiagram() {
  const nodes = document.querySelectorAll('.arch-node');
  const infoTitle = document.getElementById('arch-info-title');
  const infoDesc = document.getElementById('arch-info-desc');
  if (!infoTitle || !infoDesc) return;

  const nodeDetails = {
    'agents': {
      title: 'Distributed Log & Metric Agents',
      desc: 'Wazuh Agents deployed on Hospital HIMS nodes, EMR application hosts, MySQL replication nodes, and office developer endpoints forwarding real-time encrypted syslog.'
    },
    'manager': {
      title: 'Wazuh SIEM Manager (AWS EC2)',
      desc: 'Centralized analysis cluster applying custom decoders, CIS benchmark rulesets, behavioral anomaly checks, and File Integrity Monitoring (FIM).'
    },
    'indexer': {
      title: 'Wazuh Indexer & Elastic Storage',
      desc: 'High-performance distributed search index storing partitioned security alerts, threat telemetry, and compliance artifacts.'
    },
    'dashboard': {
      title: 'SOC Analytics & Zabbix Telemetry',
      desc: 'Unified security visualization dashboard integrated with Zabbix infrastructure telemetry for 24/7 uptime tracking and threat triage.'
    },
    'action1': {
      title: 'Action1 Automated Remediation',
      desc: 'Unified cloud endpoint management pipeline executing scheduled patching with no workday disruption.'
    }
  };

  function selectNode(node) {
    const key = node.getAttribute('data-node');
    nodes.forEach((n) => {
      const isMatch = n === node || (key && n.getAttribute('data-node') === key);
      n.classList.toggle('selected', isMatch);
      n.setAttribute('aria-pressed', String(isMatch));
    });
    if (nodeDetails[key]) {
      const banner = infoTitle.closest('.arch-info-banner') || infoTitle.parentElement;
      if (banner) {
        banner.style.transition = 'opacity 150ms ease';
        banner.style.opacity = '0.4';
        setTimeout(() => {
          infoTitle.textContent = nodeDetails[key].title;
          infoDesc.textContent = nodeDetails[key].desc;
          banner.style.opacity = '1';
        }, 120);
      } else {
        infoTitle.textContent = nodeDetails[key].title;
        infoDesc.textContent = nodeDetails[key].desc;
      }
    }
  }

  nodes.forEach((node) => {
    node.setAttribute('role', 'button');
    node.setAttribute('tabindex', '0');
    node.setAttribute('aria-pressed', String(node.classList.contains('selected')));
    node.addEventListener('click', () => selectNode(node));
    node.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        selectNode(node);
      }
    });
  });
}

/**
 * 12. Accessible Lightbox Modal for Certifications & Lab Evidence
 */
function initLightboxModal() {
  const modal = document.getElementById('lightbox-modal');
  const overlay = document.getElementById('lightbox-overlay');
  const closeBtn = document.getElementById('lightbox-close');
  const modalImg = document.getElementById('lightbox-image');
  const modalTitle = document.getElementById('lightbox-title');
  const modalCaption = document.getElementById('lightbox-caption');
  const pdfLink = document.getElementById('lightbox-pdf-link');

  if (!modal || !modalImg) return;
  let returnFocusTo = null;

  function openLightbox(src, title, caption, pdfUrl) {
    returnFocusTo = document.activeElement;
    modalImg.src = src;
    modalImg.alt = title || 'Preview';
    if (modalTitle) modalTitle.textContent = title || 'Verified Artifact';
    if (modalCaption) modalCaption.textContent = caption || 'Technical Credential / Lab Evidence';
    
    if (pdfLink) {
      if (pdfUrl) {
        pdfLink.href = pdfUrl;
        pdfLink.style.display = 'inline-flex';
      } else {
        pdfLink.style.display = 'none';
        pdfLink.removeAttribute('href');
      }
    }

    modal.classList.add('open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    if (closeBtn) closeBtn.focus();
  }

  function closeLightbox() {
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    modalImg.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'%3E%3C/svg%3E";
    if (pdfLink) pdfLink.style.display = 'none';
    if (returnFocusTo && typeof returnFocusTo.focus === 'function') returnFocusTo.focus();
  }

  // Trigger from zoom triggers & cert preview buttons
  document.addEventListener('click', (e) => {
    const trigger = e.target.closest('[data-zoom-src]');
    if (trigger) {
      e.preventDefault();
      const src = trigger.getAttribute('data-zoom-src');
      const title = trigger.getAttribute('data-zoom-title') || 'Artifact Preview';
      const caption = trigger.getAttribute('data-zoom-caption') || 'Verified Technical Artifact';
      const pdfUrl = trigger.getAttribute('data-zoom-pdf');
      openLightbox(src, title, caption, pdfUrl);
    }
  });

  if (overlay) overlay.addEventListener('click', closeLightbox);
  if (closeBtn) closeBtn.addEventListener('click', closeLightbox);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('open')) {
      closeLightbox();
    }
  });
}
