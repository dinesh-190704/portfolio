# Dinesh Mohan — Security Engineering Portfolio

A responsive, single-page portfolio for **Dinesh Mohan**, a System & Database Administrator moving into security engineering roles (Security Engineer, SOC / Detection Engineer, Infrastructure & Cloud Security).

## Design and interaction

- Dark and light themes with a cyan accent, Geist / Geist Mono typography, and Instrument Serif accents.
- Responsive project, skill, experience, and credential layouts.
- A live Chennai clock, theme transition, scroll progress, mobile navigation, and a command palette (`Ctrl+K` / `⌘K`).
- Security lab tabs, screenshot galleries, certificate lightbox, and an interactive defensive-architecture diagram.
- The Wazuh-style console is a **simulated demo feed** built from local sample events; it does not connect to a live SIEM.
- Placeholder chips remain hidden by default. The production switch is `SHOW_PLACEHOLDERS = false` in `js/main.js`; the commented real-number reference block above the impact strip in `index.html` is intentionally retained.

## Technical notes

- Plain HTML, CSS, and JavaScript; no framework, package manager, or build step is required.
- Google Fonts is the only external runtime resource. All portfolio images, certificate previews, and PDFs are served from `assets/`.
- Keyboard focus styles and reduced-motion handling are included. Run a Lighthouse and accessibility audit against the deployed site before making conformance claims.
- The same source files are mirrored in root-level `styles.css` and `script.js` for compatibility; `index.html` uses `css/style.css` and `js/main.js`.

## Free deployment to GitHub Pages

1. Initialize Git and commit the project:
   ```bash
   git init
   git add .
   git commit -m "Refine security engineering portfolio"
   git branch -M main
   ```
2. Connect the existing GitHub Pages repository:
   ```bash
   git remote add origin https://github.com/dinesh-190704/dinesh-190704.github.io.git
   git push -u origin main
   ```
3. In GitHub, open **Settings → Pages**. Select **Deploy from a branch**, choose `main` and `/(root)`, then save.
4. Portfolio URL: https://dinesh-190704.github.io/

## Directory structure

```text
├── index.html
├── css/style.css
├── js/main.js
├── styles.css
├── script.js
├── assets/
│   ├── Dinesh_Mohan_Resume.pdf
│   ├── InternalCert-Dinesh.pdf
│   ├── favicon.svg
│   ├── og-image.svg
│   └── images/ (portrait, labs, AI screenshots, credentials)
└── README.md
```
