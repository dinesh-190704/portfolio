const { spawn } = require('child_process');
const http = require('http');

async function runAudit() {
  const chromePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
  const chrome = spawn(chromePath, [
    '--headless=new',
    '--remote-debugging-port=9223',
    '--disable-gpu',
    '--no-sandbox',
    'http://127.0.0.1:4173'
  ]);

  // Wait 1.5s for Chrome to start
  await new Promise(r => setTimeout(r, 1500));

  try {
    const listRes = await fetch('http://127.0.0.1:9223/json');
    const targets = await listRes.json();
    const target = targets.find(t => t.url.includes('127.0.0.1:4173'));
    if (!target) throw new Error('Target page not found');

    const ws = new WebSocket(target.webSocketDebuggerUrl);
    let msgId = 1;
    const pending = new Map();

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.id && pending.has(data.id)) {
        const { resolve, reject } = pending.get(data.id);
        pending.delete(data.id);
        if (data.error) reject(data.error);
        else resolve(data.result);
      }
    };

    await new Promise((resolve) => ws.onopen = resolve);

    function send(method, params = {}) {
      return new Promise((resolve, reject) => {
        const id = msgId++;
        pending.set(id, { resolve, reject });
        ws.send(JSON.stringify({ id, method, params }));
      });
    }

    async function evaluate(expression) {
      const res = await send('Runtime.evaluate', {
        expression,
        returnByValue: true,
        awaitPromise: true
      });
      return res.result ? res.result.value : null;
    }

    const viewports = [375, 768, 1024, 1280, 1920];
    const tabs = [
      { id: 'lab-tab-wazuh', panelId: 'lab-panel-wazuh', name: 'Wazuh SIEM & AWS Cloud Lab' },
      { id: 'lab-tab-ollama', panelId: 'lab-panel-ollama', name: 'Local LLM & Threat Intel (Ollama)' },
      { id: 'lab-tab-architecture', panelId: 'lab-panel-architecture', name: 'Defensive Architecture Pipeline' }
    ];

    const tabResults = [];
    const viewportAudits = {};

    for (const width of viewports) {
      const height = width === 375 ? 812 : width === 768 ? 1024 : 900;
      await send('Emulation.setDeviceMetricsOverride', {
        width,
        height,
        deviceScaleFactor: 1,
        mobile: width <= 768
      });

      await new Promise(r => setTimeout(r, 300));

      // Test tabs in Security Lab
      for (const tab of tabs) {
        await evaluate(`
          (() => {
            const btn = document.getElementById('${tab.id}');
            if (btn) btn.click();
          })()
        `);
        await new Promise(r => setTimeout(r, 150));

        const metrics = await evaluate(`
          (() => {
            const sw = document.documentElement.scrollWidth;
            const iw = window.innerWidth;
            const secHead = document.querySelector('#security-lab .section-header');
            const panel = document.getElementById('${tab.panelId}');
            const container = document.querySelector('#security-lab .container');
            
            const headRect = secHead ? secHead.getBoundingClientRect() : null;
            const panelRect = panel ? panel.getBoundingClientRect() : null;
            const containerRect = container ? container.getBoundingClientRect() : null;
            
            let overflowEl = null;
            document.querySelectorAll('*').forEach(el => {
              if (el.scrollWidth > iw + 1) {
                if (!overflowEl || el.scrollWidth > overflowEl.scrollWidth) {
                  overflowEl = {
                    tag: el.tagName,
                    id: el.id,
                    className: el.className,
                    scrollWidth: el.scrollWidth
                  };
                }
              }
            });

            return {
              scrollWidth: sw,
              innerWidth: iw,
              isOverflow: sw > iw,
              headLeft: headRect ? Math.round(headRect.left) : null,
              panelLeft: panelRect ? Math.round(panelRect.left) : null,
              containerLeft: containerRect ? Math.round(containerRect.left) : null,
              panelWidth: panelRect ? Math.round(panelRect.width) : null,
              containerWidth: containerRect ? Math.round(containerRect.width) : null,
              overflowEl
            };
          })()
        `);

        tabResults.push({
          viewport: width,
          tab: tab.name,
          ...metrics
        });
      }

      // Detailed audit of headings, stat cards, and toolkit for this viewport
      const detailed = await evaluate(`
        (() => {
          // Check Headings
          const titles = Array.from(document.querySelectorAll('.section-title')).map(t => {
            const rect = t.getBoundingClientRect();
            const parent = t.closest('.container') || t.parentElement;
            const parentRect = parent ? parent.getBoundingClientRect() : null;
            const cs = window.getComputedStyle(t);
            return {
              text: t.textContent.trim().slice(0, 32),
              width: Math.round(rect.width),
              parentWidth: parentRect ? Math.round(parentRect.width) : null,
              overflowsParent: parentRect ? rect.width > parentRect.width + 1 : false,
              textWrap: cs.textWrap,
              whiteSpace: cs.whiteSpace
            };
          });

          // Check Hero Name
          const heroName = document.querySelector('.hero-name-hero');
          const heroNameMetrics = heroName ? {
            text: heroName.textContent.trim(),
            width: Math.round(heroName.getBoundingClientRect().width),
            whiteSpace: window.getComputedStyle(heroName).whiteSpace
          } : null;

          // Check Stat Cards (impact-card)
          const impactCards = Array.from(document.querySelectorAll('.impact-card')).map((c, i) => {
            const rect = c.getBoundingClientRect();
            const val = c.querySelector('.impact-value');
            const valCs = val ? window.getComputedStyle(val) : null;
            return {
              index: i + 1,
              valText: val ? val.textContent.trim() : '',
              cardHeight: Math.round(rect.height),
              cardWidth: Math.round(rect.width),
              valFontSize: valCs ? valCs.fontSize : null,
              valHeight: val ? Math.round(val.getBoundingClientRect().height) : null
            };
          });

          const cardHeights = impactCards.map(c => c.cardHeight);
          const equalHeights = cardHeights.length > 0 && cardHeights.every(h => Math.abs(h - cardHeights[0]) <= 2);

          // Check Toolkit
          const toolkitCats = Array.from(document.querySelectorAll('.toolkit-category')).map(cat => {
            const title = cat.querySelector('.toolkit-category-title');
            const tags = Array.from(cat.querySelectorAll('.tech-tag')).map(t => t.textContent.trim());
            const rect = cat.getBoundingClientRect();
            return {
              title: title ? title.textContent.trim() : '',
              tagCount: tags.length,
              width: Math.round(rect.width),
              tags
            };
          });

          // Check Hero padding & distance to impact strip
          const heroSec = document.querySelector('.hero-section');
          const impactSec = document.querySelector('.impact-strip');
          const heroRect = heroSec ? heroSec.getBoundingClientRect() : null;
          const impactRect = impactSec ? impactSec.getBoundingClientRect() : null;
          const heroActions = document.querySelector('.hero-actions');
          const actionsRect = heroActions ? heroActions.getBoundingClientRect() : null;
          const actionsToImpact = (actionsRect && impactRect) ? Math.round(impactRect.top - actionsRect.bottom) : null;

          return {
            titles,
            heroNameMetrics,
            impactCards,
            equalHeights,
            toolkitCount: toolkitCats.length,
            toolkitCats,
            actionsToImpact,
            heroPaddingBottom: heroSec ? window.getComputedStyle(heroSec).paddingBottom : null
          };
        })()
      `);

      viewportAudits[width] = detailed;
    }

    console.log('=== TAB OVERFLOW & ALIGNMENT AUDIT ===');
    console.table(tabResults.map(r => ({
      Viewport: r.viewport + 'px',
      Tab: r.tab.slice(0, 18),
      InnerWidth: r.innerWidth,
      ScrollWidth: r.scrollWidth,
      'No Overflow': !r.isOverflow,
      'Panel Left': r.panelLeft,
      'Cont Left': r.containerLeft,
      'Panel W': r.panelWidth,
      'Cont W': r.containerWidth
    })));

    console.log('\n=== STAT CARDS EQUAL HEIGHT & METRICS ===');
    for (const w of [1024, 1280, 1920]) {
      const data = viewportAudits[w];
      console.log(`\n-- Viewport ${w}px --`);
      console.log(`Equal Height: ${data.equalHeights} (Heights: ${data.impactCards.map(c => c.cardHeight + 'px').join(', ')})`);
      console.table(data.impactCards.map(c => ({
        Card: c.index,
        Value: c.valText,
        FontSize: c.valFontSize,
        CardH: c.cardHeight + 'px',
        ValH: c.valHeight + 'px'
      })));
    }

    console.log('\n=== HEADING AUDIT (1024px, 1280px, 1920px) ===');
    for (const w of [1024, 1280, 1920]) {
      const data = viewportAudits[w];
      console.log(`\n-- Viewport ${w}px (Hero: "${data.heroNameMetrics.text}" whiteSpace: ${data.heroNameMetrics.whiteSpace}) --`);
      console.table(data.titles.map(t => ({
        Title: t.text,
        Width: t.width + 'px',
        ContainerW: t.parentWidth + 'px',
        'Fits Parent': !t.overflowsParent,
        textWrap: t.textWrap,
        whiteSpace: t.whiteSpace
      })));
    }

    console.log('\n=== TOOLKIT AUDIT ===');
    console.log(`Category count: ${viewportAudits[1280].toolkitCount}`);
    viewportAudits[1280].toolkitCats.forEach((cat, i) => {
      console.log(`Col ${i+1}: "${cat.title}" (${cat.tagCount} tags) -> ${cat.tags.join(', ')}`);
    });

    console.log('\n=== HERO PADDING & CTA SPACING ===');
    for (const w of [375, 768, 1024, 1280, 1920]) {
      console.log(`Viewport ${w}px: Hero padding-bottom = ${viewportAudits[w].heroPaddingBottom}, Actions to Impact = ${viewportAudits[w].actionsToImpact}px`);
    }

    ws.close();
  } finally {
    chrome.kill();
  }
}

runAudit().catch(err => {
  console.error('Audit script error:', err);
  process.exit(1);
});
