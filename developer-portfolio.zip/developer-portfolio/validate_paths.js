const fs = require('fs');
const path = require('path');

const rootDir = process.cwd();
const html = fs.readFileSync(path.join(rootDir, 'index.html'), 'utf8');

const results = [];

function isExternal(url) {
  return url.startsWith('http://') ||
         url.startsWith('https://') ||
         url.startsWith('mailto:') ||
         url.startsWith('tel:') ||
         url.startsWith('javascript:') ||
         url.startsWith('data:') ||
         url.startsWith('#');
}

// 1. Check index.html attributes: href, src, srcset, data-zoom-src, data-zoom-pdf, data-img-src
const attrRegex = /(href|src|srcset|data-zoom-src|data-zoom-pdf|data-img-src)="([^"]*)"/g;
let match;
while ((match = attrRegex.exec(html)) !== null) {
  const attrName = match[1];
  const attrVal = match[2].trim();

  if (attrName === 'srcset') {
    const items = attrVal.split(',').map(s => s.trim().split(/\s+/)[0]);
    for (const item of items) {
      if (!isExternal(item)) {
        checkFile(item, `index.html [${attrName}]`);
      }
    }
  } else {
    if (!isExternal(attrVal)) {
      checkFile(attrVal, `index.html [${attrName}]`);
    }
  }
}

// 2. Check CSS url() in css/style.css and styles.css
function checkCssUrls(cssFile) {
  if (!fs.existsSync(cssFile)) return;
  const cssContent = fs.readFileSync(cssFile, 'utf8');
  const cssDir = path.dirname(cssFile);
  const urlRegex = /url\(\s*['"]?([^'")]+)['"]?\s*\)/g;
  let urlMatch;
  while ((urlMatch = urlRegex.exec(cssContent)) !== null) {
    const rawUrl = urlMatch[1].trim();
    if (!isExternal(rawUrl)) {
      const resolved = path.resolve(cssDir, rawUrl);
      const exists = fs.existsSync(resolved);
      results.push({
        source: path.relative(rootDir, cssFile).replace(/\\/g, '/'),
        reference: rawUrl,
        resolved: path.relative(rootDir, resolved).replace(/\\/g, '/'),
        exists
      });
    }
  }
}

checkCssUrls(path.join(rootDir, 'css/style.css'));
checkCssUrls(path.join(rootDir, 'styles.css'));

function checkFile(relPath, source) {
  const cleanPath = relPath.split('?')[0].split('#')[0];
  const fullPath = path.resolve(rootDir, cleanPath);
  const exists = fs.existsSync(fullPath);
  results.push({
    source,
    reference: relPath,
    resolved: path.relative(rootDir, fullPath).replace(/\\/g, '/'),
    exists
  });
}

console.log('=== PATH VALIDATION REPORT ===');
const broken = results.filter(r => !r.exists);
console.log(`Total local paths checked: ${results.length}`);
console.log(`Valid paths: ${results.length - broken.length}`);
console.log(`Broken paths: ${broken.length}`);

if (broken.length > 0) {
  console.log('\nBROKEN PATHS FOUND:');
  broken.forEach(b => console.log(`[BROKEN] ${b.source} -> "${b.reference}" (resolved: ${b.resolved})`));
} else {
  console.log('\nAll checked local paths exist successfully on disk!');
}

// Specifically report DPDP certificate card elements
console.log('\n--- DPDP Certificate Card Elements Check ---');
const dpdpElements = results.filter(r => r.reference.toLowerCase().includes('dpdp'));
dpdpElements.forEach(d => {
  console.log(`${d.exists ? '✓ OK' : '✗ BROKEN'} [${d.source}] ${d.reference} -> ${d.resolved}`);
});
